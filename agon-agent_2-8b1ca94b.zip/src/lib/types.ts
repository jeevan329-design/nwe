export interface Report {
  id: number;
  title: string;
  category: string;
  location: string;
  description: string;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  status: 'Pending' | 'In Progress' | 'Resolved';
  reporter_name: string;
  created_at: string;
  updated_at: string | null;
  resolved_at: string | null;
}

export const CATEGORIES = [
  'Electrical',
  'Plumbing',
  'Furniture',
  'IT & Internet',
  'Cleanliness',
  'Safety',
  'Sports Equipment',
  'Other',
] as const;

export const PRIORITIES = ['Low', 'Medium', 'High', 'Urgent'] as const;
export const STATUSES = ['Pending', 'In Progress', 'Resolved'] as const;
