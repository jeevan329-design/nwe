import type { Report } from './types';

export function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  const now = Date.now();
  const diff = Math.max(0, now - then);
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min${mins > 1 ? 's' : ''} ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} day${days > 1 ? 's' : ''} ago`;
  const months = Math.floor(days / 30);
  return `${months} month${months > 1 ? 's' : ''} ago`;
}

export function statusClasses(status: Report['status']): string {
  switch (status) {
    case 'Pending':
      return 'bg-amber-100 text-amber-800 ring-amber-300/60';
    case 'In Progress':
      return 'bg-sky-100 text-sky-800 ring-sky-300/60';
    case 'Resolved':
      return 'bg-emerald-100 text-emerald-800 ring-emerald-300/60';
  }
}

export function priorityClasses(priority: Report['priority']): string {
  switch (priority) {
    case 'Low':
      return 'bg-slate-100 text-slate-600 ring-slate-300/60';
    case 'Medium':
      return 'bg-indigo-100 text-indigo-700 ring-indigo-300/60';
    case 'High':
      return 'bg-orange-100 text-orange-700 ring-orange-300/60';
    case 'Urgent':
      return 'bg-rose-100 text-rose-700 ring-rose-300/60';
  }
}

export function categoryEmojiIcon(category: string): string {
  switch (category) {
    case 'Electrical': return '⚡';
    case 'Plumbing': return '🚰';
    case 'Furniture': return '🪑';
    case 'IT & Internet': return '💻';
    case 'Cleanliness': return '🧹';
    case 'Safety': return '🦺';
    case 'Sports Equipment': return '🏀';
    default: return '📌';
  }
}
