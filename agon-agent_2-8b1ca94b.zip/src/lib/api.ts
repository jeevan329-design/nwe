import type { Report } from './types';

const CACHE_KEY = 'kantifix_reports_cache';

export function readCache(): Report[] {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Report[];
  } catch {
    return [];
  }
}

export function writeCache(reports: Report[]) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(reports));
  } catch {
    // storage full or unavailable — ignore
  }
}

export async function fetchReports(): Promise<Report[]> {
  const res = await fetch('/api/reports');
  if (!res.ok) throw new Error('Failed to load reports');
  const data: Report[] = await res.json();
  writeCache(data);
  return data;
}

export async function createReport(payload: {
  title: string;
  category: string;
  location: string;
  description: string;
  priority: string;
  reporter_name: string;
}): Promise<Report> {
  const res = await fetch('/api/reports', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to submit report' }));
    throw new Error(err.error || 'Failed to submit report');
  }
  return res.json();
}

export async function updateStatus(id: number, status: string): Promise<Report> {
  const res = await fetch('/api/reports', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id, status }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to update status' }));
    throw new Error(err.error || 'Failed to update status');
  }
  return res.json();
}

export async function deleteReport(id: number): Promise<void> {
  const res = await fetch('/api/reports', {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to delete report' }));
    throw new Error(err.error || 'Failed to delete report');
  }
}
