import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import Reports from './pages/Reports';
import ReportForm from './pages/ReportForm';

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-canvas">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/report" element={<ReportForm />} />
            <Route path="*" element={<Dashboard />} />
          </Routes>
        </main>
        <footer className="border-t border-slate-200/70 py-6 text-center text-xs text-slate-400">
          KantiFix — Report it. Track it. Get it fixed. 🛠️
        </footer>
      </div>
    </BrowserRouter>
  );
}
