import { Flag } from 'lucide-react';
import type { Report } from '../lib/types';
import { priorityClasses } from '../lib/helpers';

export default function PriorityBadge({ priority }: { priority: Report['priority'] }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ${priorityClasses(priority)}`}
    >
      <Flag size={12} strokeWidth={2.5} />
      {priority}
    </span>
  );
}
