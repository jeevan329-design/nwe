import { Clock, Loader, CheckCircle2 } from 'lucide-react';
import type { Report } from '../lib/types';
import { statusClasses } from '../lib/helpers';

export default function StatusBadge({ status }: { status: Report['status'] }) {
  const Icon = status === 'Pending' ? Clock : status === 'In Progress' ? Loader : CheckCircle2;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ${statusClasses(status)}`}
    >
      <Icon size={13} strokeWidth={2.5} className={status === 'In Progress' ? 'animate-spin-slow' : ''} />
      {status}
    </span>
  );
}
