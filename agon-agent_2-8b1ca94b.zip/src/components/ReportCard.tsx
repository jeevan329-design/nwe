import { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, User, Trash2, ChevronDown } from 'lucide-react';
import type { Report } from '../lib/types';
import { STATUSES } from '../lib/types';
import { timeAgo, categoryEmojiIcon } from '../lib/helpers';
import StatusBadge from './StatusBadge';
import PriorityBadge from './PriorityBadge';

interface Props {
  report: Report;
  onStatusChange: (id: number, status: string) => Promise<void>;
  onDelete: (id: number) => Promise<void>;
}

export default function ReportCard({ report, onStatusChange, onDelete }: Props) {
  const [updating, setUpdating] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const handleStatus = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const next = e.target.value;
    if (next === report.status) return;
    setUpdating(true);
    try {
      await onStatusChange(report.id, next);
    } finally {
      setUpdating(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      setTimeout(() => setConfirmDelete(false), 3000);
      return;
    }
    setDeleting(true);
    try {
      await onDelete(report.id);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className={`group relative flex flex-col rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200/80 transition-shadow hover:shadow-lg hover:shadow-slate-200/60 ${
        report.status === 'Resolved' ? 'opacity-85' : ''
      }`}
    >
      <div className="mb-3 flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-50 text-lg ring-1 ring-slate-200/70">
            {categoryEmojiIcon(report.category)}
          </div>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              {report.category}
            </p>
            <h3 className="font-display text-[15px] font-bold leading-snug text-slate-800">
              {report.title}
            </h3>
          </div>
        </div>
        <button
          onClick={handleDelete}
          disabled={deleting}
          title={confirmDelete ? 'Click again to confirm' : 'Delete report'}
          className={`shrink-0 rounded-lg p-1.5 transition-colors ${
            confirmDelete
              ? 'bg-rose-100 text-rose-600'
              : 'text-slate-300 hover:bg-rose-50 hover:text-rose-500'
          } disabled:opacity-40`}
        >
          <Trash2 size={16} />
        </button>
      </div>

      <p className="mb-4 line-clamp-3 flex-1 text-sm leading-relaxed text-slate-500">
        {report.description}
      </p>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <StatusBadge status={report.status} />
        <PriorityBadge priority={report.priority} />
      </div>

      <div className="mb-4 space-y-1.5 text-xs text-slate-500">
        <p className="flex items-center gap-1.5">
          <MapPin size={13} className="text-slate-400" />
          <span className="font-medium text-slate-600">{report.location}</span>
        </p>
        <p className="flex items-center gap-1.5">
          <User size={13} className="text-slate-400" />
          {report.reporter_name} · {timeAgo(report.created_at)}
        </p>
      </div>

      <div className="relative mt-auto">
        <select
          value={report.status}
          onChange={handleStatus}
          disabled={updating}
          className="w-full cursor-pointer appearance-none rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 pr-9 text-sm font-semibold text-slate-700 transition-colors hover:border-slate-300 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-100 disabled:opacity-50"
        >
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {updating ? 'Updating…' : `Status: ${s}`}
            </option>
          ))}
        </select>
        <ChevronDown
          size={16}
          className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
        />
      </div>
    </motion.article>
  );
}
