import { motion } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';

interface Props {
  label: string;
  value: number;
  icon: LucideIcon;
  accent: string;
  iconBg: string;
  delay?: number;
}

export default function StatCard({ label, value, icon: Icon, accent, iconBg, delay = 0 }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay, ease: 'easeOut' }}
      className="flex items-center gap-4 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200/80 transition-shadow hover:shadow-md"
    >
      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${iconBg}`}>
        <Icon size={22} className={accent} strokeWidth={2.2} />
      </div>
      <div>
        <p className="font-display text-2xl font-extrabold leading-tight text-slate-800">{value}</p>
        <p className="text-[13px] font-medium text-slate-500">{label}</p>
      </div>
    </motion.div>
  );
}
