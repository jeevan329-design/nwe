import { AlertTriangle, RotateCw } from 'lucide-react';

export default function ErrorBanner({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-2xl border border-rose-200 bg-rose-50 px-6 py-8 text-center sm:flex-row sm:justify-between sm:text-left">
      <div className="flex items-center gap-3">
        <AlertTriangle size={22} className="shrink-0 text-rose-500" />
        <p className="text-sm font-medium text-rose-700">{message}</p>
      </div>
      {onRetry && (
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-1.5 rounded-xl bg-rose-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-rose-700"
        >
          <RotateCw size={15} /> Try again
        </button>
      )}
    </div>
  );
}
