import { NavLink } from 'react-router-dom';
import { Wrench, LayoutDashboard, ClipboardList, PlusCircle } from 'lucide-react';

const links = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/reports', label: 'Reports', icon: ClipboardList },
  { to: '/report', label: 'Report a Problem', icon: PlusCircle },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <NavLink to="/" className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-600 shadow-md shadow-indigo-600/25">
            <Wrench size={18} className="text-white" strokeWidth={2.5} />
          </div>
          <div className="leading-tight">
            <span className="font-display text-lg font-extrabold tracking-tight text-slate-800">
              Kanti<span className="text-indigo-600">Fix</span>
            </span>
            <p className="hidden text-[10px] font-medium uppercase tracking-widest text-slate-400 sm:block">
              School Problem Tracker
            </p>
          </div>
        </NavLink>

        <nav className="flex items-center gap-1">
          {links.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-semibold transition-colors ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-700'
                    : 'text-slate-500 hover:bg-slate-100 hover:text-slate-700'
                }`
              }
            >
              <Icon size={16} strokeWidth={2.3} />
              <span className="hidden sm:inline">{label}</span>
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
}
