import { useCallback, useEffect, useState } from 'react';
import type { Report } from '../lib/types';
import { fetchReports, updateStatus, deleteReport, readCache, writeCache } from '../lib/api';

export function useReports() {
  const [reports, setReports] = useState<Report[]>(() => readCache());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchReports();
      setReports(data);
    } catch (err) {
      const cached = readCache();
      if (cached.length > 0) {
        setReports(cached);
      } else {
        setError(err instanceof Error ? err.message : 'Failed to load reports');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const changeStatus = useCallback(async (id: number, status: string) => {
    const updated = await updateStatus(id, status);
    setReports((prev) => {
      const next = prev.map((r) => (r.id === id ? updated : r));
      writeCache(next);
      return next;
    });
  }, []);

  const remove = useCallback(async (id: number) => {
    await deleteReport(id);
    setReports((prev) => {
      const next = prev.filter((r) => r.id !== id);
      writeCache(next);
      return next;
    });
  }, []);

  return { reports, loading, error, reload: load, changeStatus, remove };
}
