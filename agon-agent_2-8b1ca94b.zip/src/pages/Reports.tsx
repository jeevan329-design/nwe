import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Search, SlidersHorizontal, PlusCircle, Inbox, X } from 'lucide-react';
import { useReports } from '../hooks/useReports';
import { CATEGORIES, STATUSES } from '../lib/types';
import ReportCard from '../components/ReportCard';
import LoadingGrid from '../components/LoadingGrid';
import ErrorBanner from '../components/ErrorBanner';

export default function Reports() {
  const { reports, loading, error, reload, changeStatus, remove } = useReports();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [status, setStatus] = useState('All');
  const [actionError, setActionError] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return reports.filter((r) => {
      if (category !== 'All' && r.category !== category) return false;
      if (status !== 'All' && r.status !== status) return false;
      if (q) {
        const haystack = `${r.title} ${r.description} ${r.location} ${r.category} ${r.reporter_name}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [reports, search, category, status]);

  const hasFilters = search.trim() !== '' || category !== 'All' || status !== 'All';

  const handleStatusChange = async (id: number, newStatus: string) => {
    setActionError(null);
    try {
      await changeStatus(id, newStatus);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to update status');
    }
  };

  const handleDelete = async (id: number) => {
    setActionError(null);
    try {
      await remove(id);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to delete report');
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"
      >
        <div>
          <h1 className="font-display text-2xl font-extrabold text-slate-800 sm:text-3xl">
            All Reports
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            {reports.length} report{reports.length !== 1 ? 's' : ''} submitted ·{' '}
            {reports.filter((r) => r.status !== 'Resolved').length} still open
          </p>
        </div>
        <Link
          to="/report"
          className="inline-flex w-fit items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-bold text-white shadow-md shadow-indigo-600/25 transition-transform hover:scale-[1.02] active:scale-[0.98]"
        >
          <PlusCircle size={16} /> New Report
        </Link>
      </motion.div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, delay: 0.08 }}
        className="mb-6 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200/80"
      >
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by title, location, description…"
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 pl-10 pr-9 text-sm text-slate-700 placeholder:text-slate-400 transition-colors focus:border-indigo-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-100"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition-colors hover:text-slate-600"
                title="Clear search"
              >
                <X size={15} />
              </button>
            )}
          </div>

          <div className="flex flex-col gap-3 sm:flex-row">
            <div className="flex items-center gap-2">
              <SlidersHorizontal size={15} className="hidden shrink-0 text-slate-400 sm:block" />
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full cursor-pointer rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-medium text-slate-700 transition-colors focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-100 sm:w-44"
              >
                <option value="All">All Categories</option>
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full cursor-pointer rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-medium text-slate-700 transition-colors focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-100 sm:w-40"
            >
              <option value="All">All Statuses</option>
              {STATUSES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            {hasFilters && (
              <button
                onClick={() => { setSearch(''); setCategory('All'); setStatus('All'); }}
                className="rounded-xl px-3 py-2.5 text-sm font-semibold text-indigo-600 transition-colors hover:bg-indigo-50"
              >
                Clear filters
              </button>
            )}
          </div>
        </div>
      </motion.div>

      {actionError && (
        <div className="mb-5">
          <ErrorBanner message={actionError} />
        </div>
      )}

      {error && !loading ? (
        <ErrorBanner message={error} onRetry={reload} />
      ) : loading && reports.length === 0 ? (
        <LoadingGrid />
      ) : filtered.length === 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-slate-300 bg-white/60 px-6 py-16 text-center"
        >
          <Inbox size={36} className="text-slate-300" />
          <p className="font-semibold text-slate-600">
            {hasFilters ? 'No reports match your filters' : 'No reports yet'}
          </p>
          <p className="max-w-xs text-sm text-slate-400">
            {hasFilters
              ? 'Try changing the search text or filters.'
              : 'When someone reports a problem, it will show up here.'}
          </p>
          {hasFilters && (
            <button
              onClick={() => { setSearch(''); setCategory('All'); setStatus('All'); }}
              className="mt-1 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-indigo-700"
            >
              Clear all filters
            </button>
          )}
        </motion.div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filtered.map((r) => (
              <ReportCard
                key={r.id}
                report={r}
                onStatusChange={handleStatusChange}
                onDelete={handleDelete}
              />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
