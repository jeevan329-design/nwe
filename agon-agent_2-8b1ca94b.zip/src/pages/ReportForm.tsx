import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send,
  CheckCircle2,
  AlertCircle,
  Type,
  MapPin,
  Tag,
  Flag,
  User,
  FileText,
  ArrowRight,
} from 'lucide-react';
import { createReport } from '../lib/api';
import { CATEGORIES, PRIORITIES } from '../lib/types';
import { categoryEmojiIcon } from '../lib/helpers';

interface FormErrors {
  title?: string;
  category?: string;
  location?: string;
  description?: string;
}

const priorityHints: Record<string, string> = {
  Low: 'Small annoyance, no rush',
  Medium: 'Should be fixed soon',
  High: 'Affects classes or many students',
  Urgent: 'Safety risk — needs attention now',
};

export default function ReportForm() {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [reporterName, setReporterName] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const validate = (): boolean => {
    const e: FormErrors = {};
    if (title.trim().length < 5) e.title = 'Please write a short title (at least 5 characters).';
    if (!category) e.category = 'Please choose a category.';
    if (location.trim().length < 3) e.location = 'Tell us where the problem is (e.g. "Room 204").';
    if (description.trim().length < 15)
      e.description = 'Please describe the problem in a bit more detail (at least 15 characters).';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    if (!validate()) return;
    setSubmitting(true);
    try {
      await createReport({
        title,
        category,
        location,
        description,
        priority,
        reporter_name: reporterName,
      });
      setSuccess(true);
      setTimeout(() => navigate('/reports'), 1800);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const fieldClass = (hasError?: string) =>
    `w-full rounded-xl border bg-slate-50 px-3.5 py-2.5 text-sm text-slate-700 placeholder:text-slate-400 transition-colors focus:bg-white focus:outline-none focus:ring-2 ${
      hasError
        ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-100'
        : 'border-slate-200 focus:border-indigo-400 focus:ring-indigo-100'
    }`;

  if (success) {
    return (
      <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-24 text-center">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 220, damping: 16 }}
          className="mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100"
        >
          <CheckCircle2 size={40} className="text-emerald-600" />
        </motion.div>
        <h1 className="font-display text-2xl font-extrabold text-slate-800">Report submitted!</h1>
        <p className="mt-2 text-sm text-slate-500">
          Thanks for helping keep the school in shape. Taking you to the reports page…
        </p>
        <Link
          to="/reports"
          className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-indigo-600 hover:text-indigo-800"
        >
          Go now <ArrowRight size={15} />
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-6">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        <h1 className="font-display text-2xl font-extrabold text-slate-800 sm:text-3xl">
          Report a Problem
        </h1>
        <p className="mt-1.5 text-sm text-slate-500">
          Spotted something broken, unsafe or not working? Fill in the details below — it takes
          less than a minute.
        </p>
      </motion.div>

      <motion.form
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.08 }}
        onSubmit={handleSubmit}
        noValidate
        className="mt-6 space-y-5 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200/80 sm:p-8"
      >
        {/* Title */}
        <div>
          <label htmlFor="title" className="mb-1.5 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
            <Type size={14} className="text-slate-400" /> Problem title <span className="text-rose-500">*</span>
          </label>
          <input
            id="title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Projector not working in Room 204"
            maxLength={100}
            className={fieldClass(errors.title)}
          />
          {errors.title && (
            <p className="mt-1.5 flex items-center gap-1 text-xs font-medium text-rose-600">
              <AlertCircle size={12} /> {errors.title}
            </p>
          )}
        </div>

        {/* Category */}
        <div>
          <label className="mb-1.5 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
            <Tag size={14} className="text-slate-400" /> Category <span className="text-rose-500">*</span>
          </label>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCategory(c)}
                className={`flex flex-col items-center gap-1 rounded-xl border px-2 py-3 text-xs font-semibold transition-all ${
                  category === c
                    ? 'border-indigo-400 bg-indigo-50 text-indigo-700 ring-2 ring-indigo-100'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-slate-300 hover:bg-white'
                }`}
              >
                <span className="text-lg">{categoryEmojiIcon(c)}</span>
                {c}
              </button>
            ))}
          </div>
          {errors.category && (
            <p className="mt-1.5 flex items-center gap-1 text-xs font-medium text-rose-600">
              <AlertCircle size={12} /> {errors.category}
            </p>
          )}
        </div>

        {/* Location */}
        <div>
          <label htmlFor="location" className="mb-1.5 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
            <MapPin size={14} className="text-slate-400" /> Location <span className="text-rose-500">*</span>
          </label>
          <input
            id="location"
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="e.g. Science Block, Room 204"
            maxLength={80}
            className={fieldClass(errors.location)}
          />
          {errors.location && (
            <p className="mt-1.5 flex items-center gap-1 text-xs font-medium text-rose-600">
              <AlertCircle size={12} /> {errors.location}
            </p>
          )}
        </div>

        {/* Description */}
        <div>
          <label htmlFor="description" className="mb-1.5 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
            <FileText size={14} className="text-slate-400" /> Description <span className="text-rose-500">*</span>
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe what's wrong, since when, and anything else that could help…"
            rows={4}
            maxLength={600}
            className={`${fieldClass(errors.description)} resize-none`}
          />
          <div className="mt-1.5 flex items-center justify-between">
            {errors.description ? (
              <p className="flex items-center gap-1 text-xs font-medium text-rose-600">
                <AlertCircle size={12} /> {errors.description}
              </p>
            ) : (
              <span />
            )}
            <span className="text-[11px] text-slate-400">{description.length}/600</span>
          </div>
        </div>

        {/* Priority */}
        <div>
          <label className="mb-1.5 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
            <Flag size={14} className="text-slate-400" /> Priority
          </label>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {PRIORITIES.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setPriority(p)}
                className={`rounded-xl border px-2 py-2.5 text-sm font-semibold transition-all ${
                  priority === p
                    ? p === 'Urgent'
                      ? 'border-rose-400 bg-rose-50 text-rose-700 ring-2 ring-rose-100'
                      : p === 'High'
                        ? 'border-orange-400 bg-orange-50 text-orange-700 ring-2 ring-orange-100'
                        : p === 'Medium'
                          ? 'border-indigo-400 bg-indigo-50 text-indigo-700 ring-2 ring-indigo-100'
                          : 'border-slate-400 bg-slate-100 text-slate-700 ring-2 ring-slate-200'
                    : 'border-slate-200 bg-slate-50 text-slate-500 hover:border-slate-300 hover:bg-white'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
          <p className="mt-1.5 text-xs text-slate-400">{priorityHints[priority]}</p>
        </div>

        {/* Name (optional) */}
        <div>
          <label htmlFor="name" className="mb-1.5 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
            <User size={14} className="text-slate-400" /> Your name{' '}
            <span className="text-xs font-normal text-slate-400">(optional)</span>
          </label>
          <input
            id="name"
            type="text"
            value={reporterName}
            onChange={(e) => setReporterName(e.target.value)}
            placeholder="e.g. Aarav, Class 10B — or leave blank to stay anonymous"
            maxLength={60}
            className={fieldClass()}
          />
        </div>

        <AnimatePresence>
          {submitError && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700"
            >
              <AlertCircle size={16} className="shrink-0" /> {submitError}
            </motion.div>
          )}
        </AnimatePresence>

        <button
          type="submit"
          disabled={submitting}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-sm font-bold text-white shadow-md shadow-indigo-600/25 transition-all hover:bg-indigo-700 hover:shadow-lg active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? (
            <>
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
              Submitting…
            </>
          ) : (
            <>
              <Send size={16} /> Submit Report
            </>
          )}
        </button>
      </motion.form>
    </div>
  );
}
