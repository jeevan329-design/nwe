import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ClipboardList,
  Clock,
  Loader,
  CheckCircle2,
  PlusCircle,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { useReports } from '../hooks/useReports';
import StatCard from '../components/StatCard';
import StatusBadge from '../components/StatusBadge';
import PriorityBadge from '../components/PriorityBadge';
import ErrorBanner from '../components/ErrorBanner';
import { timeAgo, categoryEmojiIcon } from '../lib/helpers';

export default function Dashboard() {
  const { reports, loading, error, reload } = useReports();

  const total = reports.length;
  const pending = reports.filter((r) => r.status === 'Pending').length;
  const inProgress = reports.filter((r) => r.status === 'In Progress').length;
  const resolved = reports.filter((r) => r.status === 'Resolved').length;
  const resolvedPct = total > 0 ? Math.round((resolved / total) * 100) : 0;
  const recent = reports.slice(0, 5);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      {/* Hero */}
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="relative mb-8 overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-indigo-700 to-violet-800 p-7 text-white shadow-xl shadow-indigo-600/20 sm:p-10"
      >
        <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-white/10 blur-2xl" />
        <div className="pointer-events-none absolute -bottom-20 right-24 h-40 w-40 rounded-full bg-violet-400/20 blur-xl" />
        <div className="relative">
          <p className="mb-2 text-xs font-bold uppercase tracking-[0.2em] text-indigo-200">
            Welcome to KantiFix
          </p>
          <h1 className="font-display text-2xl font-extrabold leading-tight sm:text-4xl">
            See a problem at school?
            <br className="hidden sm:block" /> Report it. Track it. Get it fixed.
          </h1>
          <p className="mt-3 max-w-lg text-sm leading-relaxed text-indigo-100 sm:text-base">
            KantiFix lets students and staff report broken equipment, safety hazards and other
            issues around campus — and follow every report until it's resolved.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              to="/report"
              className="inline-flex items-center gap-2 rounded-xl bg-white px-5 py-2.5 text-sm font-bold text-indigo-700 shadow-lg shadow-indigo-900/20 transition-transform hover:scale-[1.03] active:scale-[0.98]"
            >
              <PlusCircle size={17} /> Report a Problem
            </Link>
            <Link
              to="/reports"
              className="inline-flex items-center gap-2 rounded-xl bg-white/15 px-5 py-2.5 text-sm font-bold text-white ring-1 ring-white/30 backdrop-blur transition-colors hover:bg-white/25"
            >
              View All Reports <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </motion.section>

      {error && (
        <div className="mb-8">
          <ErrorBanner message={error} onRetry={reload} />
        </div>
      )}

      {/* Stats */}
      <section className="mb-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total Reports" value={total} icon={ClipboardList} accent="text-indigo-600" iconBg="bg-indigo-50" delay={0.05} />
        <StatCard label="Pending" value={pending} icon={Clock} accent="text-amber-600" iconBg="bg-amber-50" delay={0.1} />
        <StatCard label="In Progress" value={inProgress} icon={Loader} accent="text-sky-600" iconBg="bg-sky-50" delay={0.15} />
        <StatCard label="Resolved" value={resolved} icon={CheckCircle2} accent="text-emerald-600" iconBg="bg-emerald-50" delay={0.2} />
      </section>

      {/* Resolution rate */}
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.25 }}
        className="mb-10 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200/80"
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="flex items-center gap-2 font-display text-base font-bold text-slate-800">
            <TrendingUp size={18} className="text-emerald-500" /> Resolution Rate
          </h2>
          <span className="font-display text-lg font-extrabold text-emerald-600">{resolvedPct}%</span>
        </div>
        <div className="h-3 w-full overflow-hidden rounded-full bg-slate-100">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${resolvedPct}%` }}
            transition={{ duration: 0.8, delay: 0.4, ease: 'easeOut' }}
            className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-emerald-500"
          />
        </div>
        <p className="mt-2.5 text-xs text-slate-500">
          {resolved} of {total} reported problems have been fixed so far. Keep it up! 🎉
        </p>
      </motion.section>

      {/* Recent reports */}
      <section>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-slate-800">Recent Reports</h2>
          <Link
            to="/reports"
            className="inline-flex items-center gap-1 text-sm font-semibold text-indigo-600 transition-colors hover:text-indigo-800"
          >
            See all <ArrowRight size={15} />
          </Link>
        </div>

        {loading && reports.length === 0 ? (
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-[72px] animate-pulse rounded-2xl bg-white shadow-sm ring-1 ring-slate-200/80" />
            ))}
          </div>
        ) : recent.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white/60 px-6 py-12 text-center">
            <p className="text-sm font-medium text-slate-500">
              No reports yet. Be the first to report a problem!
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {recent.map((r, i) => (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.05 * i }}
                className="flex flex-col gap-3 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200/80 transition-shadow hover:shadow-md sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-50 text-lg ring-1 ring-slate-200/70">
                    {categoryEmojiIcon(r.category)}
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-slate-800">{r.title}</p>
                    <p className="truncate text-xs text-slate-500">
                      {r.location} · {timeAgo(r.created_at)}
                    </p>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <PriorityBadge priority={r.priority} />
                  <StatusBadge status={r.status} />
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
